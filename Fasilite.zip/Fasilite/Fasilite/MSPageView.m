//
//  MSPageView.m
//  Fasilite
//
//  Created by Shoaib on 9/18/17.
//  Copyright © 2017 Amaxza Digital. All rights reserved.
//

#import "MSPageView.h"
#import "PageCollectionViewCell.h"

@interface MSPageView ()<UICollectionViewDelegate, UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UICollectionView *pageCollectionView;

@end

static NSString* PAGE_VIEW_CELL = @"PageCollectionViewCell";

@implementation MSPageView


-(void)awakeFromNib{
    [super awakeFromNib];
    
    //UICollectionViewFlowLayout* layout=[[UICollectionViewFlowLayout alloc] init];
    //layout.itemSize = CGSizeMake(100, 20);
    [self.pageCollectionView registerNib:[UINib nibWithNibName:PAGE_VIEW_CELL bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:PAGE_VIEW_CELL];
    
    //layout.estimatedItemSize = UICollectionViewFlowLayoutAutomaticSize;
    //layout.scrollDirection=UICollectionViewScrollDirectionVertical;
    //layout.minimumInteritemSpacing = 0;
    //layout.minimumLineSpacing = 0;
    
    //self.pageCollectionView.collectionViewLayout = layout;
    //[self.pageCollectionView setContentInset:UIEdgeInsetsMake(-12, 0, 0, 0)];

}


#pragma mark - Collection View Delegate

#pragma mark - Collection View DataSource

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGSize size=CGSizeMake(self.frame.size.width, self.frame.size.width*1.1);
    
    return size;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 10;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    PageCollectionViewCell* cell=[collectionView dequeueReusableCellWithReuseIdentifier:PAGE_VIEW_CELL forIndexPath:indexPath];
    [cell.lblName setText:[NSString stringWithFormat:@"%@",self.lblTest.text]];
    return cell;
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
