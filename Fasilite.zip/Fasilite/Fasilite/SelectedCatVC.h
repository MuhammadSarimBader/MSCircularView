//
//  SelectedCatVC.h
//  Fasilite
//
//  Created by Shoaib on 9/12/17.
//  Copyright © 2017 Amaxza Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectedCatVC : UIViewController

@end
