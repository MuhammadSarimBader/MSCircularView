//
//  MSPageView.h
//  Fasilite
//
//  Created by Shoaib on 9/18/17.
//  Copyright © 2017 Amaxza Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MSPageView : UIView
@property (weak, nonatomic) IBOutlet UILabel *lblTest;

@end
