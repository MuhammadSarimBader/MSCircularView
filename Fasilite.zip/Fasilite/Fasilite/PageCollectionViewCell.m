//
//  PageCollectionViewCell.m
//  Fasilite
//
//  Created by Shoaib on 9/21/17.
//  Copyright © 2017 Amaxza Digital. All rights reserved.
//

#import "PageCollectionViewCell.h"


@interface PageCollectionViewCell ()

@end

@implementation PageCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _lblDiscount.layer.cornerRadius=4;
    _lblDiscount.layer.borderWidth = 1.0f;
    //[_lblDiscount.layer setBorderColor:[UIColor colorWithRed:248/255 green:80/255 blue:50/255 alpha:1].CGColor];
    _lblDiscount.layer.borderColor=[UIColor colorWithRed:0.97254f green:0.3137f blue:0.196f alpha:1].CGColor;

}

@end
