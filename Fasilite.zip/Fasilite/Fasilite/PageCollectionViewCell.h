//
//  PageCollectionViewCell.h
//  Fasilite
//
//  Created by Shoaib on 9/21/17.
//  Copyright © 2017 Amaxza Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblDiscount;
@end
